<?php
/**
 * Author Personal Blog Theme Global Options
 */
require get_theme_file_path('inc/customizer/themeoptions/book-slider.php');