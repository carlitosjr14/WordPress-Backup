<?php
require_once get_theme_file_path( 'inc/widgets/latest-posts.php' );