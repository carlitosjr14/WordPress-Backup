<?php
/**
 * Register Block Style
 */
register_block_style( 'core/quote', array(
	'name'         => 'red-qoute',
    'label'        => __( 'Red Quote', 'author-personal-blog' ),
    'is_default'   => true,
));
