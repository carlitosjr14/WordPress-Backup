<div class="cookies-per-purpose">
    <div class="purpose"><h4>{purpose}</h4></div>
    {cookies_per_purpose}
</div>