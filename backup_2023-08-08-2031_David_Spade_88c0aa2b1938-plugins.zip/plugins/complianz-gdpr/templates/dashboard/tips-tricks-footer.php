<?php defined('ABSPATH') or die("you do not have access to this page!"); ?>

<a href="https://complianz.io/docs/" class="button button-default" target="_blank"><?php _e("View all", "complianz-gdpr")?></a>
