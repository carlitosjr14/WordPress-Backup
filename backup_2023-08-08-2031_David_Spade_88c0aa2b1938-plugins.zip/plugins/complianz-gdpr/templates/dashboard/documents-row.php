<div class="cmplz-document cmplz-{status}">
	<div>{title}</div>
	{page_exists}
	{sync_icon}
	{shortcode_icon}
	<div>{generated}</div>
</div>
