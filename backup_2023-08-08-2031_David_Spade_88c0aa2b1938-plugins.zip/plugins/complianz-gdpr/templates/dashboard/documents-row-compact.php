<div class="cmplz-document compact cmplz-{status}">
	<div>{title}</div>
	<div>{control}</div>
</div>
