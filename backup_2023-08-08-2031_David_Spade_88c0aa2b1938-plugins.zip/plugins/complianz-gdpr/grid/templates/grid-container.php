<div class="cmplz-grid">
    {content}
</div>
