<div class="cmplz-step {class}" {conditions}>
	<div class="cmplz-step-header"><a class="cmplz-link-{name}" href="#{name}"><h2>{header}</h2></a></div>
</div>
